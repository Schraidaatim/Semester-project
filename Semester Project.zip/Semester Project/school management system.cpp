#include <iostream>
using namespace std;

	
void student(){
	cout<<"Welcome to school management system for Students"<<endl;
	cout<<"input your data"<<endl;
	cout<<" \n";
string name1,name2,name3;
cout<<"Enter Full name"<<endl;
cin>>name1;
cin>>name2;
cin>>name3;
string indexnumder="UEB3262222";
cout<<"Index number: "<< indexnumder<<endl;

string phonenumber="0502058435";
cout<<"Phone number: "<<phonenumber <<endl;

string address="schraidaa@gmail.com";
cout<<"Address: " <<address<<endl;

string  grade= "3.1";
cout<<"Grade: "<<grade<<endl;

string courseinformation1="Information Technology";
cout<<"Programe: "<<courseinformation1<<endl;

	}
	
void teacher(){
	cout<<"Welcome to school management system for Teachers"<<endl;
	cout<<"input your data"<<endl;
	cout<<""<<endl;
	string name1,name2,name3;
	cout<<"Enter Full name"<<endl;
	cin>>name1;
    cin>>name2;
     cin>>name3;

string phonenumber="0502058435";
cout<<"Phone number: "<<phonenumber <<endl;

string address="Leonardnattangmail.com";
cout<<"Address: " <<address<<endl;

	
	string courseteaching="Computer Ethics: ";
	cout<<"Course teaching: "<< courseteaching<<endl;
	
	
	
}	
	
int main() {	
cout<<"Welcome to Divine school tracking system"<<endl;
cout<<"1. Student tracker"<<endl;
cout<<"2. Teacher tracker"<<endl;
int input;
cin>>input;
if(input==1){
student();	
}
	else if(input==2){
	 teacher();	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	return 0;
}
